package nim241054007_.AryaSutaKhafid.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.core.net.toUri

class MainActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.editTextNumberSigned)
        val age = findViewById<EditText>(R.id.editTextNumberSigned2)
        val buttonSend = findViewById<Button>(R.id.button)
        val buttoncall = findViewById<ImageButton>(R.id.imageView2)

        buttoncall.setOnClickListener{
            val myIntent = Intent(packageContent = this, cls = Activity2::class.java)
            myIntent.putExtra(name = "Extra-name", value = name.text.toString())
            myIntent.putExtra(name = "Extra-age", value = age.text.toString())
            startActivity(myIntent)
        }

        buttoncall.setOnClickListener{
            val phoneNumber = "085752986954"
            val dialPhoneIntent = Intent(action = Intent.ACTION_DIAL,
                Uri.parse(uriString = "tel:$phoneNumber".toUri())
            )
            startActivity(dialPhoneIntent)
        }
    }
}